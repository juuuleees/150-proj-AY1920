RUZ, Julianne Marie
2014-04280
CMSC 150 B-1L

Github repo: https://github.com/juuuleees/150-proj-AY1920

References:
	Running app from script: 
		https://stackoverflow.com/questions/35986731/launch-and-terminate-shiny-app-through-terminal/49837091 
	Shiny tutorials:
		https://rstudio.github.io/shiny/tutorial/#ui-and-server
		https://shiny.rstudio.com/reference/shiny/latest/renderTable.html
		https://bookdown.org/weicheng/shinyTutorial/ui.html
		https://stackoverflow.com/questions/41233242/add-remove-input-fields-dynamically-by-a-button-in-shiny-and-keep-values
		https://shiny.rstudio.com/articles/action-buttons.html
		https://swcarpentry.github.io/
		https://stackoverflow.com/questions/23233497/outputting-multiple-lines-of-text-with-rendertext-in-r-shiny
	Misc.:
		https://stackoverflow.com/questions/33297959/read-csv-and-assign-values-to-r-variables
		https://stackoverflow.com/questions/41428626/r-shiny-read-a-table-from-file-and-use-it
		r-novice-inflammation/11-supp-read-write-csv/
		https://discuss.analyticsvidhya.com/t/how-to-remove-value-from-a-vector-in-r/2975
	Installations:
		https://www.digitalocean.com/community/tutorials/how-to-install-r-on-ubuntu-18-04
		https://linuxconfig.org/install-deb-file-on-ubuntu-18-04-bionic-beaver-linux
		https://linuxconfig.org/rstudio-on-ubuntu-18-04-bionic-beaver-linux
