#!/bin/bash

Rscript -e 'library(methods); shiny::runApp("src", launch.browser=TRUE)'
